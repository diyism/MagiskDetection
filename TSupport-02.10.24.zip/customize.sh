#/system/bin/bash
#
finish() {
    echo "> Installed."
}
#
available() {
    echo """
if [ -d /data/adb/modules/tricky_store ] && [ -d /data/adb/modules/zygisk_shamiko ]; then
    sed -i 's/^description=.*/description=[😋Working as Support for: ✅Tricky Store. ✅Shamiko] Support module for TrickyStore and Shamiko./' \"/data/adb/modules/tsupport/module.prop\"
elif [ ! -d /data/adb/modules/tricky_store ]; then
    sed -i 's/^description=.*/description=[😋Working as Support for: ❌Tricky Store. ✅Shamiko] Support module for TrickyStore and Shamiko./' \"/data/adb/modules/tsupport/module.prop\"
elif [ ! -d /data/adb/modules/zygisk_shamiko ]; then
    sed -i 's/^description=.*/description=[😋Working as Support for: ✅Tricky Store. ❌Shamiko] Support module for TrickyStore and Shamiko./' \"/data/adb/modules/tsupport/module.prop\"
else
    sed -i 's/^description=.*/description=[❌ Environment not supported] Support module for TrickyStore and Shamiko./' \"/data/adb/modules/tsupport/module.prop\"
fi
""" >> $MODPATH/post-fs-data.sh
}
#
tsu() {
    echo """
if [ -d /data/adb/modules/tricky_store ] && [ -f /data/adb/modules/tsupport/.nomedia ]; then
    [ -f /data/adb/tricky_store/keybox.xml.bak ] && rm -rf /data/adb/tricky_store/keybox.xml.bak
    [ -f /data/adb/tricky_store/keybox.xml ] && mv /data/adb/tricky_store/keybox.xml /data/adb/tricky_store/keybox.xml.bak
    cp /data/adb/modules/tsupport/.nomedia /data/adb/tricky_store/keybox.xml
elif [ ! -d /data/adb/modules/tricky_store ] && [ ! -d /data/adb/modules/zygisk_shamiko ]; then
    rm -rf /data/adb/tricky_store && rm -rf /data/adb/modules/tsupport
fi
""" >> $MODPATH/post-fs-data.sh
}
#
shamsu() {
    if [ -f $MODPATH/.log ]; then
        echo """
if [ -d /data/adb/modules/zygisk_shamiko ]; then
    if [ -f /data/adb/modules/tsupport/.log ]; then
        [ -f /data/adb/modules/tsupport/action.sh ] && rm -rf /data/adb/modules/action.sh
        cp /data/adb/modules/tsupport/.log /data/adb/modules/tsupport/action.sh
    else
        echo \"echo \"! Something wrong, Please Reinstall.\" && sleep 2.8\" > /data/adb/modules/tsupport/action.sh
    fi  
else
    if [ -f /data/adb/modules/tsupport/action.sh ]; then
        rm -rf /data/adb/modules/tsupport/action.sh
    fi
    rm -rf /data/adb/shamiko
fi""" >> $MODPATH/post-fs-data.sh
    else
        abort "! Suspend Something Wrong, Please Reinstall."
    fi
}
#
check3() {
    if [ -f "$MODPATH/.nomedia" ] && [ -f "$MODPATH/.log" ]; then
        if [ -f "/data/adb/tricky_store/keybox.xml" ]; then
            mv /data/adb/tricky_store/keybox.xml /data/adb/tricky_store/keybox.xml.bak
        fi
        tsu
        shamsu
        available
        finish
    else
        abort "! Suspend. Something Wrong, Please Reinstall."
    fi
}

check2() {
    if [ -d /data/adb/modules/zygisk_shamiko ]; then
        ui_print "> Shamiko Detected!"
        sleep 0.5
        ui_print "> Working as Shamiko Support"
        tsu
        shamsu
        available
        finish
    else
        abort "! Shamiko not Detected!"
        sleep 0.5
    fi
    
}
#
check() {
    if [ -d "/data/adb/modules/tricky_store" ]; then
        ui_print "> TrickyStore Detected!" | ui_print "> Adapting..."
        sleep 0.5
        if [ -f "/data/adb/tricky_store/keybox.xml.bak" ]; then
            ui_print "! Old Trace Detected!"
            ui_print "> Cleaning Trace"
            rm "/data/adb/tricky_store/keybox.xml.bak"
        fi
        sleep 0.5
        check3
    else
        ui_print "! TrickyStore not detected"
        check2
    fi
}
#
start() {
    ui_print "> Initialization.."
    #
    if [ "`grep_prop id $MODPATH/module.prop`" != "tsupport" ]; then
        abort "! Suspend. Something Wrong, Please Reinstall."
    fi
    check
}
#
start