# Setting Directory
MODPATH="$(dirname "$(readlink -f "$0")")"

# Set directory variable
TARGET_DIR="/data/adb/tricky_store"
TARGET_FILE="$TARGET_DIR/target.txt"
TARGET_BACKUP="$TARGET_DIR/target.txt.bak"
ROM_SIGN_PATH="/system/etc/security"

### Core Function

# Define abort function
abort() {
    echo -e "$@"
    exit 1
}

# Function to check Internet connectivity
check_internet() {
    # Try to connect to 8.8.8.8 with a 3-second timeout
    if ! timeout 3 ping -c 1 8.8.8.8 > /dev/null 2>&1; then
        # If ping to 8.8.8.8 fails, try google.com
        if ! timeout 3 ping -c 1 google.com > /dev/null 2>&1; then
            # Abort if both checks fail
            abort "! Unable to connect to Internet"
        fi
    fi
}

cleaner() {

    # Remove the key file if it exists
    [ -f $MODPATH/key ] && rm -rf "$MODPATH/key"
    
    # Remove PIXEL_BETA_HTML file if it exists
    [ -f $DIR/PIXEL_BETA_HTML ] && su -c "rm -rf $MODPATH/BETA"
    
    # Remove PIXEL_GET_HTML file if it exists
    [ -f $DIR/PIXEL_GET_HTML ] && su -c "rm -rf $MODPATH/GET_PIXEL"
    
    # Remove PIXEL_GSI_HTML file if it exists
    [ -f $DIR/PIXEL_GSI_HTML ] && su -c "rm -rf $MODPATH/PIXEL"
    
}

# Random Function
random() {
    choices="secure secure secure rolled"
    num_choices=$(echo "$choices" | wc -w)
    random_index=$(awk -v min=1 -v max="$num_choices" 'BEGIN {srand(); print int(min + rand() * (max - min + 1))}')
    echo "$choices" | awk -v idx="$random_index" '{print $idx}'
}

# Mode Function

fingerprint() {
    # Check if the fp.sh file exists and execute it with root privileges
    [ -f "$MODPATH/fp.sh" ] && sh "$MODPATH/fp.sh" || echo -e "! ERR: 1 - error to get fingerprint"   
}

keybox() {
    # Get Key
    [ -f "$MODPATH/key.sh" ] && sh "$MODPATH/key.sh" "https://raw.githubusercontent.com/citra-standalone/Citra-Standalone/main/zipball/$(random).tar" || { [ "$(cmd sh "$MODPATH/key.sh"; echo $?)" -eq 2 ] || echo -e "! ERR: 1 - error to get blackbox"; }
}

shamiko() {
    # Displaying a message regarding TSupport and Shamiko support
    echo "=== TSP Shamiko Support ==="
    
    # Define the path to the Shamiko configuration directory
    PATH="/data/adb/shamiko"
    
    [ ! -d /data/adb/modules/zygisk_shamiko ] && rm -rf $PATH
    
    # Check if the whitelist file exists
    if [ -d $PATH ] && [ -f $PATH/whitelist ]; then
        echo "> Shamiko Mode : Whitelist"  # Notify that Shamiko is in the whitelist
        sleep 1.5  # Pause for 1 second
        echo "> Change to Blacklist"  # Notify the user about changing to blacklist
        rm -rf $PATH/whitelist  # Remove the whitelist file
    
    # Check if the blacklist file exists (assuming this was meant)
    elif [ -d $PATH ] && [ ! -f $PATH/whitelist ]; then
        echo "> Shamiko Mode : Blacklist"  # Notify that Shamiko is not whitelisted
        sleep 1.5  # Pause for 1 second
        echo "> Change to Whitelist"  # Notify the user about changing to whitelist
        touch $PATH/whitelist  # Create the whitelist file
    
    # If Shamiko is neither whitelisted nor blacklisted
    else
        echo "! Shamiko not detected"  # Notify that Shamiko is not detected
        sleep 1.3 && exit
    fi
    
    # Sleep for 1 seconds and print result then sleep 1.3 second before exiting the script
    sleep 1 && echo "> Done" && sleep 1.3 && exit
}

key() {
    local option_name=$1
    local option1=$2
    local option2=$3
    local results=$4

    echo "[ VOL+ ] = [ $option1 ]"
    echo "[ VOL- ] = [ $option2 ]"
    echo "[ POWR ] = [ EXIT ]"
    echo -e "\nYour selection for $option_name ?"

    local maxtouch=3  # Set the touch
    local touches=0  # Initialize elapsed time

    while true; do
        keys=$(getevent -lqc1)
        
        # Check for timeout
        if [ "$touches" -ge "$maxtouch" ]; then
            abort "! No Response, abort ..."
            cleaner
            sleep 1
            break
        fi

        if echo "$keys" | grep -q 'KEY_VOLUMEUP.*DOWN'; then
            echo "$option_name set to $option1"
            result=0
            return 0  # Return with success status for option1
        elif echo "$keys" | grep -q 'KEY_VOLUMEDOWN.*DOWN'; then
            echo "$option_name set to $option2"
            result=1
            return 1  # Return with success status for option2
        elif echo "$keys" | grep -q 'KEY_POWER.*DOWN'; then
            abort "! Power key detected, abort ..."
            cleaner
            sleep 1
            break
        fi
        sleep 1
        touches=$((touches + 1))  # Increment the elapsed time
    done
}


# ===========

echo -e "\n============================"

# Auto Target Detection
if [ -f /sdcard/stop-tspa-auto-target ]; then
    echo "Auto Target : offline"
elif [ ! -f /sdcard/stop-tspa-auto-target ]; then
    echo "Auto Target : online"
else
    echo "Auto Target : unknown"
fi

# ROM Sign Check
if unzip -l $ROM_SIGN_PATH/otacerts.zip | grep -q "testkey" ; then
    echo -e "ROM Sign : testkey"
elif unzip -l $ROM_SIGN_PATH/otacerts.zip | grep -q "releasekey" ; then
    echo -e "ROM Sign : releasekey"
else
    echo -e "ROM Sign : unknown"
fi

# SELinux Check
if [ "$(getenforce)" == "Enforcing" ]; then
    echo -e "SELinux : enforcing"
elif [ "$(getenforce)" == "Permissive" ]; then
    echo -e "SELinux : permissive"
else
    echo -e "SELinux : disabled"
fi

# TEE Detection
if [ -d "$TARGET_DIR" ] && grep -q "teeBroken=true" "$TARGET_DIR/tee_status"; then
    echo -e "TEE Status : broken"
elif [ -d "$TARGET_DIR" ] && grep -q "teeBroken=false" "$TARGET_DIR/tee_status"; then
    echo -e "TEE Status : normal"
else
    echo -e "TEE Status : unknown"
fi

# XiaomiEU Disable Inject Module
if cat /data/system/packages.list | awk '{print $1}' | grep eu.xiaomi.module.inject >> /dev/null || getprop ro.product.mod_device | grep xiaomieu; then
    echo "XEU ROM : true"
    su -c pm disable eu.xiaomi.module.inject >> /dev/null
else
    echo "XEU ROM : false"
fi

# Close Indicator
echo "============================"

# Check if the Tricky Store directory exists
if [ -d "$TARGET_DIR" ]; then
    # Check if target.txt exists
    if [ -f "$TARGET_FILE" ]; then
        # If a backup of target.txt exists, remove target.txt
        if [ -f "$TARGET_BACKUP" ]; then
            su -c rm -rf "$TARGET_FILE"
        else
            # Otherwise, back up target.txt
            su -c mv "$TARGET_FILE" "$TARGET_BACKUP" && ui_print "> Backup done🥰"
        fi
    fi

    # Get all installed package names
    packages=$(awk '{print $1}' /data/system/packages.list)

    # CITarget Indicator
    if head -n 1 /sdcard/customize.txt | grep -q "^!$"; then
        echo -e "\n=== CITarget-GCS-MODE ==="
    else
        echo -e "\n=== CITarget-AUTO-MODE ==="
    fi
    [ -f /sdcard/customize.txt ] && echo "> customize.txt found"
    
    # Loop through each package
    for package in $packages; do
        if [ -f /sdcard/customize.txt ]; then
            # Check if package is forced with GCS mode (!), LHM mode (?), or excluded
            if grep -q "^$package!$" /sdcard/customize.txt; then
                echo "> $package force use \"!\" [GCS]"
                echo "$package!" >> "$TARGET_FILE"
                continue
    
            elif grep -q "teeBroken=false" "$TARGET_DIR/tee_status" && grep -q "^$package?$" /sdcard/customize.txt; then
                echo "> $package force use \"?\" [LHM]"
                echo "$package?" >> "$TARGET_FILE"
                continue
    
            elif grep -q "^$package$" /sdcard/customize.txt; then
                echo "> $package excluded"
                sleep 0.5
                continue
            fi
    
            # If the first line is "!", force GCS mode for all remaining packages
            if head -n 1 /sdcard/customize.txt | grep -q "^!$"; then
                echo "$package!" >> "$TARGET_FILE"
            else
                echo "$package" >> "$TARGET_FILE"  # Default Auto Mode
            fi
        else
            # If no customize.txt, use Auto Mode
            echo "$package" >> "$TARGET_FILE"
        fi
    done

    echo "> Done adding package to target.txt"
    echo "=== ENDED ==="

else
    # Message from Citra
    echo "=== ERROR ==="
    sleep 1
    echo "! TrickyStore folder not detected"
    sleep 0.5
    echo "=== ENDED ==="
fi

# Mode Selector
echo -e "\n=== TSP-A Action Mode Selector ==="
key "Action Mode" "Fprint Updater" "Bbox Updater" result

# Runner Script
if [ "$result" -eq 0 ]; then
    check_internet
    fingerprint
    cleaner
    sleep 1
    exit 0
elif [ "$result" -eq 1 ]; then
    check_internet
    keybox
    cleaner
    sleep 1
    exit 0
else
    cleaner
    sleep 1.5
    exit 1
fi