# Define Directory
SHAMIKO="/data/adb/modules/zygisk_shamiko"

# Delete Old Action
[ -f $SHAMIKO/action.sh ] && rm -rf $SHAMIKO/action.sh

# Identity Spoofer 1
spoof1() {
resetprop ro.build.fingerprint "Xiaomi/apollopro_global/apollo:12/RKQ1.211001.001/V14.0.4.0.SJDMIXM:user/release-keys"
resetprop ro.product.model "M2007J3SG"
# resetprop ro.product.manufacturer "Xiaomi" // Causing error to some app
}
# Identity Spoofer 2
spoof2() {
resetprop ro.build.fingerprint "Xiaomi/ishtar/ishtar:14/V816.0.12.0.UMACNXM:user/release-keys"
resetprop ro.product.model "2304FPN6DC"
# resetprop ro.product.manufacturer "Xiaomi" // Causing error to some app
}
# Spoofer Runner
# spoof1
# spoof2