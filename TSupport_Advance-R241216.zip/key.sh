#!/system/bin/sh

# Indicator
echo -e "\n=== CIT Beebox Retriever ==="

# Setting Directory
DIR="$(dirname "$(readlink -f "$0")")"
cd "$DIR" || exit 1

# Default URL (this can be overridden by the argument)
URL="https://raw.githubusercontent.com/citra-standalone/Citra-Standalone/main/bin"

# Check if a URL argument is provided
if [ -n "$1" ]; then
    URL="$1"
fi

abort() {
    echo -e "$@"
    exit 1
}

# Define cleaner
cleaner() {
    [ -f $DIR/key ] && rm -rf "$DIR/key"
}

# Detect busybox
get_busybox() {
    BUSYBOX=""
    for potential_path in /data/adb/modules/busybox-ndk/system/*/busybox /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox; do
        if [ -f "$potential_path" ]; then
            BUSYBOX="$potential_path"
            break  # Stop the loop after finding the first valid BusyBox
        fi
    done

    if [ -z "$BUSYBOX" ]; then
        echo "! BusyBox not found"
        exit 1  # Exit if BusyBox is not found
    fi
}

# Call the function to detect BusyBox
get_busybox

# Define wget using the detected BusyBox
wget() {
    if [ -n "$BUSYBOX" ]; then
        su -c "$BUSYBOX" wget "$@"  # Use the found BusyBox to execute wget
    else
        echo "! BusyBox is not set. Cannot define wget."
        exit 1
    fi
}

key() {
    local option_name=$1
    local option1=$2
    local option2=$3
    local result_var=$4

    echo -e "\n[ VOL+ ] = [ $option1 ]"
    echo "[ VOL- ] = [ $option2 ]"
    echo "[ POWR ] = [ ABORT ]"
    echo -e "\nYour selection for $option_name ?"

    local maxtouch=3  # Set the touch
    local touches=0  # Initialize elapsed time

    while true; do
        keys=$(getevent -lqc1)
        
        # Check for timeout
        if [ "$touches" -ge "$maxtouch" ]; then
            echo "! No response, abort ..."  # Print timeout message
            cleaner
            echo "! Aborted"
            sleep 1
            exit 0  # Exit if power key is pressed
        fi

        if echo "$keys" | grep -q 'KEY_VOLUMEUP.*DOWN'; then
            echo "> Backup overwritten"
            # eval "$result_var=\"$option1\""  # Store the result in the provided variable
            result=1
            return 1  # Return with success status for option1
        elif echo "$keys" | grep -q 'KEY_VOLUMEDOWN.*DOWN'; then
            echo "> Backup skiped"
            # eval "$result_var=\"$option2\""  # Store the result in the provided variable
            result=0
            return 0  # Return with success status for option2
        elif echo "$keys" | grep -q 'KEY_POWER.*DOWN'; then
            echo -e "! Power key detected, abort ..."
            cleaner
            echo "! Aborted"
            sleep 1
            exit 0  # Exit if power key is pressed
        fi
        sleep 1
        touches=$((touches + 1))  # Increment the elapsed time
    done
}

# Download key using the URL from argument or default
echo "> Retrieving latest key ..."
wget -q -O key --no-check-certificate $URL 2>&1 || exit 1

# Decrypt and delete
base64 -d key > keys && sleep 1 && cat keys > key && rm keys

# Read file content
file_content=$(cat key)

# Filtering and set variable
ID=$(grep '^ID=' key | cut -d'=' -f2-)
ecdsa_key=$(echo "$file_content" | sed -n '/<Key algorithm="ecdsa">/,/<\/Key>/p')
rsa_key=$(echo "$file_content" | sed -n '/<Key algorithm="rsa">/,/<\/Key>/p')

# Getting Information
echo -e "> Getting information ~ Key: $ID"
sleep 0.5
echo "> Dumping latest key information ..."
sleep 0.5

# Check for missing variables
if [ -z "$ID" ]; then
    echo "! Error: ID not found in key file"
    cleaner
    exit 1
fi

if [ -z "$ecdsa_key" ]; then
    echo "! Error: ECDSA key not found in key file"
    cleaner
    exit 1
fi

if [ -z "$rsa_key" ]; then
    echo "! Error: RSA key not found in key file"
    cleaner
    exit 1
fi

# Generate keybox.xml
if [ -d /data/adb/tricky_store ]; then
    echo "> Saving to keybox.xml ..."
    cat <<EOF > keybox.xml
<?xml version="1.0"?>
<AndroidAttestation>
<NumberOfKeyboxes>1</NumberOfKeyboxes>
<Keybox DeviceID="$ID">
$ecdsa_key
$rsa_key
</Keybox>
</AndroidAttestation>
# Citra-Standalone, CITraces - https://t.me/citraintegritytrick/3 - Citra, a standalone implementation, leaves a trace in IoT.
EOF
    
    if [ -f /data/adb/tricky_store/keybox.xml.bak ] && [ -f /data/adb/tricky_store/keybox.xml ]; then
        echo "! Backup exist"
        result=2
        key backup OVERWRITE SKIP result
        
        if [ "$result" -eq 0 ]; then
            mv "$DIR/keybox.xml" /data/adb/tricky_store/keybox.xml
        elif [ "$result" -eq 1 ]; then
            cat /data/adb/tricky_store/keybox.xml > /data/adb/tricky_store/keybox.xml.bak
            mv "$DIR/keybox.xml" /data/adb/tricky_store/keybox.xml
        elif [ "$result" -eq 2 ]; then
            cleaner
            exit 2
        else
            exit 2
        fi
    elif [ ! -f /data/adb/tricky_store/keybox.xml.bak ] && [ -f /data/adb/tricky_store/keybox.xml ]; then
        cat /data/adb/tricky_store/keybox.xml > /data/adb/tricky_store/keybox.xml.bak
        mv "$DIR/keybox.xml" /data/adb/tricky_store/keybox.xml
    else
        mv "$DIR/keybox.xml" /data/adb/tricky_store/keybox.xml
    fi
    sleep 0.5
    [ -f /data/adb/tricky_store/keybox.xml ] && echo "> Successfully retrieved keybox.xml"
else
    echo "! No tricky store found"
fi

# Clean up
cleaner
killall -v com.google.android.gms >> /dev/null
killall -v com.google.android.gms.unstable >> /dev/null
echo "=== ENDED ==="