#Restoration Function
rm -rf /data/adb/modules/zygisk_shamiko/action.sh
rm -rf /data/adb/pif.json
# cat /data/adb/tricky_store/keybox.xml.bak > /data/adb/tricky_store/keybox.xml || rm -rf /data/adb/tricky_store/keybox.xml.bak